#Jacob Goodman
#CSCI T599 Intro to Comp and Prog
#Assignment 5 Airline Program
#July 6 2022 2:30pm

def main():
    name_list = open("names.txt").read().split("\n")
    nlist_first_last = []
    for i in name_list:
        nlist_first_last.append(i.split())

    print("Passenger List:")
    for i in nlist_first_last:
        print(i[0], i[1])

if __name__ == '__main__':
    main()

